'use client';

import { PageTemplate } from '../../../components/ui/PageTemplate';

export default function AnuncisPage() {
  const statsData = [
    { label: 'Total Anuncis', value: '234', trend: '+15%' },
    { label: 'Els Meus Anuncis', value: '3', trend: '+1' },
    { label: 'Nous Avui', value: '8', trend: '+2' },
    { label: 'Visualitzacions', value: '1.5K', trend: '+28%' }
  ];

  return (
    <PageTemplate
      title="Anuncis"
      subtitle="Descobreix oportunitats i publica els teus anuncis"
      statsData={statsData}
    >
      <div style={{ padding: '0 24px 24px 24px' }}>
        <p style={{ fontSize: '16px', color: '#6c757d', textAlign: 'center', marginTop: '40px' }}>
          Sistema d'anuncis es desenvoluparà aquí
        </p>
      </div>
    </PageTemplate>
  );
}