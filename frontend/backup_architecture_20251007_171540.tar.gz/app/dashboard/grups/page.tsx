'use client';

import { PageTemplate } from '../../../components/ui/PageTemplate';

export default function GrupsPage() {
  const statsData = [
    { label: 'Total Grups', value: '89', trend: '+5%' },
    { label: 'Els Meus Grups', value: '7', trend: '+2' },
    { label: 'Nous Aquest Mes', value: '12', trend: '+4' },
    { label: 'Membres Total', value: '3.2K', trend: '+22%' }
  ];

  return (
    <PageTemplate
      title="Grups"
      subtitle="Uneix-te a comunitats d'interès professional"
      statsData={statsData}
    >
      <div style={{ padding: '0 24px 24px 24px' }}>
        <p style={{ fontSize: '16px', color: '#6c757d', textAlign: 'center', marginTop: '40px' }}>
          Gestió de grups es desenvoluparà aquí
        </p>
      </div>
    </PageTemplate>
  );
}