'use client';

import { PageTemplate } from '../../../components/ui/PageTemplate';

export default function EnllaçosPage() {
  const statsData = [
    { label: 'Enllaços Disponibles', value: '89', trend: '+7%' },
    { label: 'Més Visitats', value: '12', trend: '+3' },
    { label: 'Nous Aquest Mes', value: '5', trend: '+2' },
    { label: 'Categories', value: '15', trend: '+1' }
  ];

  return (
    <PageTemplate
      title="Enllaços d'Interès"
      subtitle="Recursos útils per al sector públic"
      statsData={statsData}
    >
      <div style={{ padding: '0 24px 24px 24px' }}>
        <p style={{ fontSize: '16px', color: '#6c757d', textAlign: 'center', marginTop: '40px' }}>
          Directori d'enllaços d'interès es desenvoluparà aquí
        </p>
      </div>
    </PageTemplate>
  );
}