'use client';

import { usePathname } from 'next/navigation';
import Link from 'next/link';

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  const comunitatItems = [
    { href: '/dashboard', label: 'Tauler' },
    { href: '/dashboard/perfil', label: 'El Meu Perfil' },
    { href: '/dashboard/membres', label: 'Membres' },
    { href: '/dashboard/grups', label: 'Grups' },
    { href: '/dashboard/missatges', label: 'Missatges' },
    { href: '/dashboard/forums', label: 'Fòrums' },
    { href: '/dashboard/blogs', label: 'Blogs' },
    { href: '/dashboard/anuncis', label: 'Anuncis' },
  ];

  const serveisItems = [
    { href: '/dashboard/empreses', label: 'Empreses i Col·laboradors' },
    { href: '/dashboard/ofertes', label: 'Ofertes' },
    { href: '/dashboard/assessorament', label: 'Assessorament' },
    { href: '/dashboard/enllacos', label: "Enllaços d'Interès" },
    { href: '/dashboard/formacio', label: 'Formació' },
    { href: '/dashboard/recursos', label: 'Recursos' },
  ];

  const quickActions = [
    { href: '#', label: 'Cercar' },
    { href: '#', label: 'Notificacions' },
    { href: '#', label: 'Calendari' },
  ];

  const isActive = (href: string) => {
    if (href === '/dashboard') {
      return pathname === '/dashboard';
    }
    return pathname.startsWith(href);
  };

  return (
    <div style={{
      display: 'flex',
      height: '100vh',
      backgroundColor: 'white',
      fontFamily: 'system-ui, -apple-system, sans-serif'
    }}>
      {/* Sidebar */}
      <aside style={{
        width: '280px',
        backgroundColor: 'white',
        borderRight: '1px solid #e0e0e0',
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        position: 'fixed',
        left: 0,
        top: 0
      }}>
        {/* Logo - Fixed */}
        <div style={{
          height: '64px',
          padding: '0 24px',
          borderBottom: '1px solid #e0e0e0',
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          backgroundColor: 'white',
          position: 'sticky',
          top: 0,
          zIndex: 101
        }}>
          <div style={{
            width: '40px',
            height: '40px',
            borderRadius: '8px',
            background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            fontSize: '20px',
            fontWeight: 'bold'
          }}>
            P
          </div>
          <div>
            <h2 style={{ margin: 0, fontSize: '18px', fontWeight: 'bold', color: '#1a1a1a' }}>
              La pública
            </h2>
            <p style={{ margin: 0, fontSize: '12px', color: '#666' }}>
              Comunitat Social
            </p>
          </div>
        </div>

        {/* Navigation Container - Scrollable */}
        <div style={{
          flex: 1,
          overflowY: 'auto',
          paddingBottom: '20px'
        }}>
          {/* COMUNITAT */}
          <div style={{ padding: '20px 16px' }}>
            <p style={{
              fontSize: '11px',
              fontWeight: '600',
              color: '#999',
              letterSpacing: '0.5px',
              textTransform: 'uppercase',
              margin: '0 0 12px 12px'
            }}>
              Comunitat
            </p>
            <nav style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
              {comunitatItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    padding: '10px 12px',
                    borderRadius: '8px',
                    textDecoration: 'none',
                    fontSize: '14px',
                    fontWeight: '500',
                    backgroundColor: isActive(item.href) ? '#3b82f6' : 'transparent',
                    color: isActive(item.href) ? 'white' : '#4a4a4a',
                    transition: 'all 0.2s'
                  }}
                >
                  <span>{item.label}</span>
                </Link>
              ))}
            </nav>
          </div>

          {/* SERVEIS */}
          <div style={{ padding: '20px 16px', borderTop: '1px solid #f0f0f0' }}>
            <p style={{
              fontSize: '11px',
              fontWeight: '600',
              color: '#999',
              letterSpacing: '0.5px',
              textTransform: 'uppercase',
              margin: '0 0 12px 12px'
            }}>
              Serveis
            </p>
            <nav style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
              {serveisItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    padding: '10px 12px',
                    borderRadius: '8px',
                    textDecoration: 'none',
                    fontSize: '14px',
                    fontWeight: '500',
                    backgroundColor: isActive(item.href) ? '#3b82f6' : 'transparent',
                    color: isActive(item.href) ? 'white' : '#4a4a4a',
                    transition: 'all 0.2s'
                  }}
                >
                  <span>{item.label}</span>
                </Link>
              ))}
            </nav>
          </div>

          {/* Accions Ràpides */}
          <div style={{ padding: '20px 16px', borderTop: '1px solid #f0f0f0' }}>
            <p style={{
              fontSize: '11px',
              fontWeight: '600',
              color: '#999',
              letterSpacing: '0.5px',
              textTransform: 'uppercase',
              margin: '0 0 12px 12px'
            }}>
              Accions Ràpides
            </p>
            <nav style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
              {quickActions.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    padding: '10px 12px',
                    borderRadius: '8px',
                    textDecoration: 'none',
                    fontSize: '14px',
                    fontWeight: '500',
                    color: '#4a4a4a',
                    transition: 'all 0.2s'
                  }}
                >
                  <span>{item.label}</span>
                </Link>
              ))}
            </nav>
          </div>
        </div>
      </aside>

      {/* Header */}
      <header style={{
        height: '64px',
        backgroundColor: 'white',
        borderBottom: '1px solid #e0e0e0',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 24px',
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      }}>
        {/* Logo */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          marginLeft: '24px'
        }}>
          <div style={{
            width: '40px',
            height: '40px',
            borderRadius: '8px',
            background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            fontSize: '20px',
            fontWeight: 'bold'
          }}>
            P
          </div>
          <div>
            <h2 style={{ margin: 0, fontSize: '18px', fontWeight: 'bold', color: '#1a1a1a' }}>
              La pública
            </h2>
            <p style={{ margin: 0, fontSize: '12px', color: '#666' }}>
              Comunitat Social
            </p>
          </div>
        </div>

        {/* Search Bar */}
        <div style={{
          flex: 1,
          maxWidth: '600px',
          margin: '0 auto'
        }}>
          <div style={{
            position: 'relative'
          }}>
            <span style={{
              position: 'absolute',
              left: '12px',
              top: '50%',
              transform: 'translateY(-50%)',
              fontSize: '16px'
            }}>
              🔍
            </span>
            <input
              type="text"
              placeholder="Buscar membres, grups, activitats..."
              style={{
                width: '100%',
                padding: '10px 12px 10px 40px',
                borderRadius: '8px',
                border: '1px solid #e0e0e0',
                fontSize: '14px',
                backgroundColor: '#f8f8f8'
              }}
            />
          </div>
        </div>

        {/* Right Actions */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '16px'
        }}>
            {/* Create Post Button */}
            <button style={{
              padding: '8px 20px',
              borderRadius: '8px',
              border: 'none',
              background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
              color: 'white',
              fontSize: '14px',
              fontWeight: '600',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span style={{ fontSize: '20px' }}>+</span>
              Crear Post
            </button>

            {/* Theme Toggle */}
            <button style={{
              width: '40px',
              height: '40px',
              borderRadius: '8px',
              border: '1px solid #e0e0e0',
              backgroundColor: 'white',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              fontSize: '18px'
            }}>
              🌙
            </button>

            {/* Shopping Cart */}
            <button style={{
              width: '40px',
              height: '40px',
              borderRadius: '8px',
              border: '1px solid #e0e0e0',
              backgroundColor: 'white',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              fontSize: '18px',
              position: 'relative'
            }}>
              🛒
              <span style={{
                position: 'absolute',
                top: '-4px',
                right: '-4px',
                backgroundColor: '#ef4444',
                color: 'white',
                borderRadius: '50%',
                width: '20px',
                height: '20px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '11px',
                fontWeight: 'bold'
              }}>
                3
              </span>
            </button>

            {/* Notifications */}
            <button style={{
              width: '40px',
              height: '40px',
              borderRadius: '8px',
              border: '1px solid #e0e0e0',
              backgroundColor: 'white',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              fontSize: '18px',
              position: 'relative'
            }}>
              🔔
              <span style={{
                position: 'absolute',
                top: '-4px',
                right: '-4px',
                backgroundColor: '#ef4444',
                color: 'white',
                borderRadius: '50%',
                width: '20px',
                height: '20px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '11px',
                fontWeight: 'bold'
              }}>
                7
              </span>
            </button>

            {/* Profile */}
            <button style={{
              padding: '8px 12px',
              borderRadius: '8px',
              border: '1px solid #e0e0e0',
              backgroundColor: 'white',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              cursor: 'pointer'
            }}>
              <div style={{
                width: '32px',
                height: '32px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontWeight: 'bold',
                fontSize: '14px'
              }}>
                AL
              </div>
              <span style={{ fontSize: '14px', fontWeight: '500', color: '#4a4a4a' }}>
                Admin
              </span>
            </button>
        </div>
      </header>

      {/* Main Content Area */}
      <div style={{
        flex: 1,
        marginLeft: '280px',
        marginTop: '64px', // Espacio para el header fijo
        display: 'flex',
        flexDirection: 'column',
        height: 'calc(100% - 64px)'
      }}>
        {/* Page Content */}
        <main style={{
          flex: 1,
          overflowY: 'auto',
          backgroundColor: '#f8f9fa'
        }}>
          {children}
        </main>
      </div>
    </div>
  );
}