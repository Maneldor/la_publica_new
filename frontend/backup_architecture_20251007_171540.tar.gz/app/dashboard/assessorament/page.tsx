'use client';

import { PageTemplate } from '../../../components/ui/PageTemplate';

export default function AssessoramentPage() {
  const statsData = [
    { label: 'Consultors Disponibles', value: '34', trend: '+6%' },
    { label: 'Sessions Avui', value: '8', trend: '+2' },
    { label: 'Les Meves Sessions', value: '12', trend: '+3' },
    { label: 'Hores Totals', value: '48h', trend: '+15h' }
  ];

  return (
    <PageTemplate
      title="Assessorament"
      subtitle="Accedeix a serveis d'assessorament professional"
      statsData={statsData}
    >
      <div style={{ padding: '0 24px 24px 24px' }}>
        <p style={{ fontSize: '16px', color: '#6c757d', textAlign: 'center', marginTop: '40px' }}>
          Plataforma d'assessorament es desenvoluparà aquí
        </p>
      </div>
    </PageTemplate>
  );
}