'use client';

import { PageTemplate } from '../../../components/ui/PageTemplate';

export default function FormacioPage() {
  const statsData = [
    { label: 'Cursos Disponibles', value: '45', trend: '+8%' },
    { label: 'Els Meus Cursos', value: '3', trend: '+1' },
    { label: 'Certificats Obtinguts', value: '7', trend: '+2' },
    { label: 'Hores de Formació', value: '120h', trend: '+25h' }
  ];

  return (
    <PageTemplate
      title="Formació"
      subtitle="Accedeix a cursos i programes de desenvolupament professional"
      statsData={statsData}
    >
      <div style={{ padding: '0 24px 24px 24px' }}>
        <p style={{ fontSize: '16px', color: '#6c757d', textAlign: 'center', marginTop: '40px' }}>
          Plataforma de formació es desenvoluparà aquí
        </p>
      </div>
    </PageTemplate>
  );
}