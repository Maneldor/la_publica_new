'use client';

import { PageTemplate } from '../../../components/ui/PageTemplate';

export default function EmpresesesPage() {
  const statsData = [
    { label: 'Empreses Registrades', value: '156', trend: '+12%' },
    { label: 'Col·laboradors Actius', value: '89', trend: '+8%' },
    { label: 'Nous Aquest Mes', value: '7', trend: '+2' },
    { label: 'Projectes Actius', value: '34', trend: '+15%' }
  ];

  return (
    <PageTemplate
      title="Empreses i Col·laboradors"
      subtitle="Connecta amb empreses i professionals del sector"
      statsData={statsData}
    >
      <div style={{ padding: '0 24px 24px 24px' }}>
        <p style={{ fontSize: '16px', color: '#6c757d', textAlign: 'center', marginTop: '40px' }}>
          Directori d'empreses i col·laboradors es desenvoluparà aquí
        </p>
      </div>
    </PageTemplate>
  );
}