'use client';

import { PageTemplate } from '../../components/ui/PageTemplate';

export default function DashboardPage() {
  const statsData = [
    { label: 'Membres Actius', value: '2.4K', trend: '+18%' },
    { label: 'Activitat Avui', value: '156', trend: '+7%' },
    { label: 'Grups', value: '89', trend: '+5%' },
    { label: 'Missatges', value: '1.2K', trend: '+23%' }
  ];

  return (
    <PageTemplate
      title="Tauler"
      subtitle="Benvingut a la comunitat de La Pública"
      statsData={statsData}
    >
      <div style={{
        display: 'grid',
        gridTemplateColumns: '320px 1fr 320px',
        gap: '24px',
        padding: '0 24px 24px 24px',
        maxWidth: '1400px',
        margin: '0 auto'
      }}>
      {/* Left Column - Following */}
      <div>
        <div style={{
          backgroundColor: '#fff',
          borderRadius: '12px',
          padding: '20px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          marginBottom: '20px'
        }}>
          <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px', color: '#2c3e50' }}>
            Seguint
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {[
              { name: 'Maria García', role: 'Administradora', avatar: '👩‍💼' },
              { name: 'Joan Martí', role: 'Desenvolupador', avatar: '👨‍💻' },
              { name: 'Anna Soler', role: 'Analista', avatar: '👩‍🔬' }
            ].map((user, index) => (
              <div key={index} style={{
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                padding: '8px',
                borderRadius: '8px',
                backgroundColor: '#f8f9fa',
                cursor: 'pointer'
              }}>
                <div style={{
                  width: '40px',
                  height: '40px',
                  borderRadius: '50%',
                  backgroundColor: '#e9ecef',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '18px'
                }}>
                  {user.avatar}
                </div>
                <div>
                  <div style={{ fontSize: '14px', fontWeight: '500', color: '#2c3e50' }}>
                    {user.name}
                  </div>
                  <div style={{ fontSize: '12px', color: '#6c757d' }}>
                    {user.role}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div style={{
          backgroundColor: '#fff',
          borderRadius: '12px',
          padding: '20px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px', color: '#2c3e50' }}>
            Grups
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {[
              { name: 'Desenvolupadors Web', members: 45 },
              { name: 'Administració Digital', members: 32 },
              { name: 'Innovació Pública', members: 28 }
            ].map((group, index) => (
              <div key={index} style={{
                padding: '12px',
                borderRadius: '8px',
                backgroundColor: '#f8f9fa',
                cursor: 'pointer'
              }}>
                <div style={{ fontSize: '14px', fontWeight: '500', color: '#2c3e50', marginBottom: '4px' }}>
                  {group.name}
                </div>
                <div style={{ fontSize: '12px', color: '#6c757d' }}>
                  {group.members} membres
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Middle Column - Activity Feed */}
      <div>
        <div style={{
          backgroundColor: '#fff',
          borderRadius: '12px',
          padding: '20px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          marginBottom: '20px'
        }}>
          <h2 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '16px', color: '#2c3e50' }}>
            Activitat Recent
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {[
              {
                user: 'Maria García',
                action: 'ha publicat una actualització',
                time: 'Fa 2 hores',
                content: 'Hem implementat les noves funcionalitats del portal de transparència...'
              },
              {
                user: 'Joan Martí',
                action: 'ha compartit un document',
                time: 'Fa 4 hores',
                content: 'Guia de bones pràctiques per al desenvolupament d\'aplicacions públiques'
              },
              {
                user: 'Anna Soler',
                action: 'ha creat un nou grup',
                time: 'Fa 6 hores',
                content: 'Grup: Anàlisi de Dades Públiques'
              }
            ].map((post, index) => (
              <div key={index} style={{
                padding: '16px',
                borderRadius: '8px',
                backgroundColor: '#f8f9fa',
                border: '1px solid #e9ecef'
              }}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  marginBottom: '12px'
                }}>
                  <div style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '50%',
                    backgroundColor: '#3b82f6',
                    color: 'white',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '14px',
                    fontWeight: '600'
                  }}>
                    {post.user.charAt(0)}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      fontSize: '14px'
                    }}>
                      <span style={{ fontWeight: '600', color: '#2c3e50' }}>
                        {post.user}
                      </span>
                      <span style={{ color: '#6c757d' }}>
                        {post.action}
                      </span>
                    </div>
                    <div style={{ fontSize: '12px', color: '#6c757d' }}>
                      {post.time}
                    </div>
                  </div>
                </div>
                <div style={{ fontSize: '14px', color: '#495057', lineHeight: '1.4' }}>
                  {post.content}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right Column - Profile & Companies */}
      <div>
        <div style={{
          backgroundColor: '#fff',
          borderRadius: '12px',
          padding: '20px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          marginBottom: '20px'
        }}>
          <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px', color: '#2c3e50' }}>
            El teu Perfil
          </h3>
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            textAlign: 'center'
          }}>
            <div style={{
              width: '60px',
              height: '60px',
              borderRadius: '50%',
              backgroundColor: '#3b82f6',
              color: 'white',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '24px',
              fontWeight: '600',
              marginBottom: '12px'
            }}>
              U
            </div>
            <div style={{ fontSize: '16px', fontWeight: '600', color: '#2c3e50', marginBottom: '4px' }}>
              Usuari
            </div>
            <div style={{ fontSize: '12px', color: '#6c757d', marginBottom: '16px' }}>
              Empleat Públic
            </div>
            <div style={{
              width: '100%',
              backgroundColor: '#e9ecef',
              borderRadius: '8px',
              height: '8px',
              marginBottom: '8px'
            }}>
              <div style={{
                width: '75%',
                backgroundColor: '#28a745',
                height: '8px',
                borderRadius: '8px'
              }} />
            </div>
            <div style={{ fontSize: '12px', color: '#6c757d' }}>
              Perfil completat al 75%
            </div>
          </div>
        </div>

        <div style={{
          backgroundColor: '#fff',
          borderRadius: '12px',
          padding: '20px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px', color: '#2c3e50' }}>
            Organitzacions
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {[
              { name: 'Ajuntament de Barcelona', type: 'Administració Local' },
              { name: 'Generalitat de Catalunya', type: 'Administració Autonòmica' },
              { name: 'Ministeri de Digitalització', type: 'Administració Estatal' }
            ].map((org, index) => (
              <div key={index} style={{
                padding: '12px',
                borderRadius: '8px',
                backgroundColor: '#f8f9fa',
                cursor: 'pointer'
              }}>
                <div style={{ fontSize: '14px', fontWeight: '500', color: '#2c3e50', marginBottom: '4px' }}>
                  {org.name}
                </div>
                <div style={{ fontSize: '12px', color: '#6c757d' }}>
                  {org.type}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      </div>
    </PageTemplate>
  );
}