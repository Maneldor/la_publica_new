'use client';

import { PageTemplate } from '../../../components/ui/PageTemplate';

export default function ForumsPage() {
  const statsData = [
    { label: 'Total Fòrums', value: '45', trend: '+3%' },
    { label: 'Els Meus Posts', value: '18', trend: '+5' },
    { label: 'Respostes Avui', value: '34', trend: '+12' },
    { label: 'Temes Actius', value: '127', trend: '+8%' }
  ];

  return (
    <PageTemplate
      title="Fòrums"
      subtitle="Participa en discussions sobre temes d'interès professional"
      statsData={statsData}
    >
      <div style={{ padding: '0 24px 24px 24px' }}>
        <p style={{ fontSize: '16px', color: '#6c757d', textAlign: 'center', marginTop: '40px' }}>
          Sistema de fòrums es desenvoluparà aquí
        </p>
      </div>
    </PageTemplate>
  );
}