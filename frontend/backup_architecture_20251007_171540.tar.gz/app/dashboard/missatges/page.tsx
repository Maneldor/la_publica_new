'use client';

import { PageTemplate } from '../../../components/ui/PageTemplate';

export default function MissatgesPage() {
  const statsData = [
    { label: 'Total Missatges', value: '1.2K', trend: '+23%' },
    { label: 'No Llegits', value: '8', trend: '+2' },
    { label: 'Enviats Avui', value: '15', trend: '+5' },
    { label: 'Converses Actives', value: '12', trend: '+3' }
  ];

  return (
    <PageTemplate
      title="Missatges"
      subtitle="Comunicació directa amb altres membres"
      statsData={statsData}
    >
      <div style={{ padding: '0 24px 24px 24px' }}>
        <p style={{ fontSize: '16px', color: '#6c757d', textAlign: 'center', marginTop: '40px' }}>
          Sistema de missatgeria es desenvoluparà aquí
        </p>
      </div>
    </PageTemplate>
  );
}