'use client';

import { PageTemplate } from '../../../components/ui/PageTemplate';

export default function RecursosPage() {
  const statsData = [
    { label: 'Recursos Disponibles', value: '278', trend: '+22%' },
    { label: 'Descarregats Avui', value: '45', trend: '+12' },
    { label: 'Els Meus Recursos', value: '18', trend: '+4' },
    { label: 'Categories', value: '12', trend: '+2' }
  ];

  return (
    <PageTemplate
      title="Recursos"
      subtitle="Accedeix a documents, plantilles i eines útils"
      statsData={statsData}
    >
      <div style={{ padding: '0 24px 24px 24px' }}>
        <p style={{ fontSize: '16px', color: '#6c757d', textAlign: 'center', marginTop: '40px' }}>
          Biblioteca de recursos es desenvoluparà aquí
        </p>
      </div>
    </PageTemplate>
  );
}