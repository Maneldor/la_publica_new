'use client';

import { PageTemplate } from '../../../components/ui/PageTemplate';

export default function MembresPage() {
  const statsData = [
    { label: 'Total Membres', value: '2.4K', trend: '+18%' },
    { label: 'Nous Avui', value: '12', trend: '+3' },
    { label: 'Actius Aquest Mes', value: '1.8K', trend: '+15%' },
    { label: 'En Línia Ara', value: '89', trend: '+7' }
  ];

  return (
    <PageTemplate
      title="Membres"
      subtitle="Connecta amb altres professionals del sector públic"
      statsData={statsData}
    >
      <div style={{ padding: '0 24px 24px 24px' }}>
        <p style={{ fontSize: '16px', color: '#6c757d', textAlign: 'center', marginTop: '40px' }}>
          Directori de membres es desenvoluparà aquí
        </p>
      </div>
    </PageTemplate>
  );
}