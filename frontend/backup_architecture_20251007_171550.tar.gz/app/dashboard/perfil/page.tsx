'use client';

import { PageTemplate } from '../../../components/ui/PageTemplate';

export default function PerfilPage() {
  const statsData = [
    { label: 'Perfil Completat', value: '85%', trend: '+5%' },
    { label: 'Connexions', value: '142', trend: '+12' },
    { label: 'Posts Publicats', value: '23', trend: '+3' },
    { label: 'Likes Rebuts', value: '367', trend: '+45' }
  ];

  return (
    <PageTemplate
      title="El Meu Perfil"
      subtitle="Gestiona la teva informació personal i configuració"
      statsData={statsData}
    >
      <div style={{ padding: '0 24px 24px 24px' }}>
        <p style={{ fontSize: '16px', color: '#6c757d', textAlign: 'center', marginTop: '40px' }}>
          Contingut específic del perfil es desenvoluparà aquí
        </p>
      </div>
    </PageTemplate>
  );
}