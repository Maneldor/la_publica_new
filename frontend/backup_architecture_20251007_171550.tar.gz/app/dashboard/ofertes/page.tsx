'use client';

import { PageTemplate } from '../../../components/ui/PageTemplate';

export default function OferterPage() {
  const statsData = [
    { label: 'Ofertes Actives', value: '67', trend: '+9%' },
    { label: 'Aplicacions Avui', value: '23', trend: '+5' },
    { label: 'Les Meves Aplicacions', value: '4', trend: '+1' },
    { label: 'Entrevistes Programades', value: '2', trend: '+1' }
  ];

  return (
    <PageTemplate
      title="Ofertes"
      subtitle="Troba oportunitats laborals al sector públic"
      statsData={statsData}
    >
      <div style={{ padding: '0 24px 24px 24px' }}>
        <p style={{ fontSize: '16px', color: '#6c757d', textAlign: 'center', marginTop: '40px' }}>
          Portal d'ofertes laborals es desenvoluparà aquí
        </p>
      </div>
    </PageTemplate>
  );
}