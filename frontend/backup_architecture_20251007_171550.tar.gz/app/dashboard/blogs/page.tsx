'use client';

import { PageTemplate } from '../../../components/ui/PageTemplate';
import { UniversalCard } from '../../../components/ui/UniversalCard';

export default function BlogsPage() {
  const statsData = [
    { label: 'Total Blogs', value: '128', trend: '+12%' },
    { label: 'Publicacions Avui', value: '5', trend: '+2' },
    { label: 'Comentaris', value: '342', trend: '+8%' },
    { label: 'Visualitzacions', value: '2.1K', trend: '+15%' }
  ];

  const blogPosts = [
    {
      id: 1,
      title: 'Digitalització de l\'Administració Pública',
      excerpt: 'Les noves tecnologies estan transformant la manera com les administracions públiques presten els seus serveis...',
      author: 'Maria García',
      date: '2 dies',
      category: 'Tecnologia',
      comments: 12,
      views: 245
    },
    {
      id: 2,
      title: 'Transparència i Governança Digital',
      excerpt: 'La transparència és un pilar fonamental de la democràcia moderna. En aquest article analitzem...',
      author: 'Joan Martí',
      date: '3 dies',
      category: 'Governança',
      comments: 8,
      views: 189
    },
    {
      id: 3,
      title: 'Sostenibilitat en el Sector Públic',
      excerpt: 'Com podem integrar criteris de sostenibilitat en les polítiques públiques i la gestió administrativa...',
      author: 'Anna Soler',
      date: '5 dies',
      category: 'Sostenibilitat',
      comments: 15,
      views: 312
    },
    {
      id: 4,
      title: 'Innovació en Serveis Públics',
      excerpt: 'La innovació oberta està revolucionant la prestació de serveis públics a través de la col·laboració...',
      author: 'Pere López',
      date: '1 setmana',
      category: 'Innovació',
      comments: 6,
      views: 156
    },
    {
      id: 5,
      title: 'Ciberseguretat en l\'Administració',
      excerpt: 'Els reptes de seguretat digital que enfronten les administracions públiques en l\'era digital...',
      author: 'Laura Vidal',
      date: '1 setmana',
      category: 'Seguretat',
      comments: 11,
      views: 278
    },
    {
      id: 6,
      title: 'Participació Ciutadana Digital',
      excerpt: 'Les plataformes digitals ofereixen noves oportunitats per a la participació ciutadana activa...',
      author: 'Carles Roca',
      date: '2 setmanes',
      category: 'Participació',
      comments: 9,
      views: 201
    },
    {
      id: 7,
      title: 'Formació Contínua per a Empleats Públics',
      excerpt: 'La importància de la formació contínua en un entorn de canvi constant i transformació digital...',
      author: 'Montse Vila',
      date: '2 setmanes',
      category: 'Formació',
      comments: 7,
      views: 167
    },
    {
      id: 8,
      title: 'Col·laboració Interadministrativa',
      excerpt: 'Estratègies per millorar la coordinació i col·laboració entre diferents nivells administratius...',
      author: 'David Camps',
      date: '3 setmanes',
      category: 'Col·laboració',
      comments: 13,
      views: 289
    }
  ];

  const getCategoryColor = (category: string) => {
    const colors = {
      'Tecnologia': '#3b82f6',
      'Governança': '#10b981',
      'Sostenibilitat': '#22c55e',
      'Innovació': '#f59e0b',
      'Seguretat': '#ef4444',
      'Participació': '#8b5cf6',
      'Formació': '#06b6d4',
      'Col·laboració': '#f97316'
    };
    return colors[category as keyof typeof colors] || '#6b7280';
  };

  return (
    <PageTemplate
      title="Blogs"
      subtitle="Descobreix articles i reflexions dels membres de la comunitat"
      statsData={statsData}
    >

      {/* Filter Bar */}
      <div style={{
        backgroundColor: '#fff',
        padding: '16px 20px',
        borderRadius: '12px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        marginBottom: '24px',
        margin: '0 24px 24px 24px',
        display: 'flex',
        alignItems: 'center',
        gap: '16px'
      }}>
        <span style={{ fontSize: '14px', fontWeight: '500', color: '#495057' }}>
          Filtrar per:
        </span>
        <div style={{ display: 'flex', gap: '8px' }}>
          {['Tots', 'Tecnologia', 'Governança', 'Innovació'].map((filter, index) => (
            <button key={index} style={{
              padding: '6px 12px',
              borderRadius: '6px',
              border: index === 0 ? '2px solid #3b82f6' : '1px solid #e9ecef',
              backgroundColor: index === 0 ? '#3b82f6' : '#fff',
              color: index === 0 ? '#fff' : '#495057',
              fontSize: '12px',
              fontWeight: '500',
              cursor: 'pointer'
            }}>
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* Blog Grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gap: '24px',
        padding: '0 24px 24px 24px'
      }}>
        {blogPosts.map((post) => (
          <UniversalCard
            key={post.id}
            topZone={{
              type: 'gradient',
              value: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
              height: 120,
              badge: {
                text: post.category,
                color: getCategoryColor(post.category),
                position: 'top-right'
              }
            }}
            middleZone={{
              title: post.title,
              description: post.excerpt,
              metadata: {
                avatar: {
                  text: post.author.charAt(0),
                  size: 'sm'
                },
                author: post.author,
                date: `Fa ${post.date}`
              }
            }}
            bottomZone={{
              stats: [
                { icon: '💬', value: post.comments },
                { icon: '👁', value: post.views }
              ],
              primaryAction: {
                text: 'Llegir més →',
                style: 'link'
              }
            }}
            onClick={() => console.log('Click on blog', post.id)}
          />
        ))}
      </div>
    </PageTemplate>
  );
}